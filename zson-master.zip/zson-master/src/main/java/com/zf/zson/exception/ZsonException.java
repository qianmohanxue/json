package com.zf.zson.exception;

/**
 * Created by zhangfei on 2018/1/31/031.
 */
public class ZsonException extends RuntimeException {

	public ZsonException() {
	}

	public ZsonException(String message) {
		super(message);
	}

}
