package com.zf.zson.path;

public class ZsonCurrentPath {

	private Integer index;

	private String key;

	public Integer getIndex() {
		return index;
	}

	public void setIndex(Integer index) {
		this.index = index;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

}
